import sys
from typing import Optional
import os
import json
import csv
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime, timedelta

import imaplib
import email
from email.header import decode_header
from email.utils import parseaddr, parsedate_to_datetime
from email.message import Message

# Use tkcalendar for a date-picker widget.
# To enable the calendar view, install it via command line: pip install tkcalendar
try:
    from tkcalendar import DateEntry as TKCalDateEntry
    TKCAL_AVAILABLE = True
except ImportError:
    TKCAL_AVAILABLE = False
    TKCalDateEntry = None

# Attempt to use ttkbootstrap for modern styling
BOOTSTRAP_AVAILABLE = False
try:
    import ttkbootstrap as tb
    PRIMARY = 'primary'
    BOOTSTRAP_AVAILABLE = True
except ImportError:
    pass


# ----------------------------- Dummy Email Dataset -----------------------------
DUMMY_EMAILS = [
    {
        "name": "Alice Johnson",
        "email": "alice@example.com",
        "subject": "Project Update",
        "body": "Hi team, here is the latest update on the project. We have completed the first milestone and are on track for the next phase. Please review the attached documents and provide your feedback by Friday.",
        "date": datetime.now() - timedelta(days=1, hours=2),
    },
    {
        "name": "Bob Smith",
        "email": "bob@example.com",
        "subject": "Meeting Invitation",
        "body": "You are invited to our quarterly planning meeting. Agenda includes roadmap review, resource allocation, and risk assessment. Kindly confirm your availability.",
        "date": datetime.now() - timedelta(days=3, hours=5),
    },
    {
        "name": "Carol Lee",
        "email": "carol@example.com",
        "subject": "Invoice 2025-09",
        "body": "Hello, please find attached the invoice for September 2025. Let us know if you have any questions.",
        "date": datetime.now() - timedelta(days=10),
    },
    {
        "name": "David Green",
        "email": "david@example.com",
        "subject": "Welcome Aboard",
        "body": "Welcome to the company! We are excited to have you. Here are some resources to get started...",
        "date": datetime.now() - timedelta(days=15),
    },
    {
        "name": "Eve Turner",
        "email": "eve@example.com",
        "subject": "Follow-up on Proposal",
        "body": "Following up on the proposal sent last week. Do you have any questions or feedback? We can schedule a call to discuss details.",
        "date": datetime.now() - timedelta(days=20),
    },
]


# ----------------------------- Helpers -----------------------------
# Safely decodes email headers to a readable string.
def safe_decode_header(raw_header: str) -> str:
    if not raw_header:
        return ""
    parts = decode_header(raw_header)
    decoded = []
    for part, enc in parts:
        try:
            if isinstance(part, bytes):
                decoded.append(part.decode(enc or "utf-8", errors="ignore"))
            else:
                decoded.append(part)
        except Exception:
            try:
                decoded.append(part.decode("utf-8", errors="ignore"))  # type: ignore
            except Exception:
                decoded.append(str(part))
    return "".join(decoded)


# Extracts the plain text body from an email message.
def parse_email_body(msg: Message) -> str:
    try:
        if msg.is_multipart():
            for part in msg.walk():
                ctype = part.get_content_type()
                disp = str(part.get("Content-Disposition") or "")
                if ctype == "text/plain" and "attachment" not in disp:
                    payload = part.get_payload(decode=True) or b""
                    return payload.decode(part.get_content_charset() or "utf-8", errors="ignore")
        else:
            payload = msg.get_payload(decode=True) or b""
            return payload.decode(msg.get_content_charset() or "utf-8", errors="ignore")
    except Exception:
        return ""
    return ""


# Converts a datetime object to the IMAP-required date format.
def to_imap_date(d: datetime) -> str:
    return d.strftime("%d-%b-%Y")


# ----------------------------- IMAP Connection -----------------------------
# Connects and logs into an IMAP server.
def connect_imap(server: str, email_address: str, password: str, use_ssl: bool = True, mailbox: str = "INBOX"):
    """Attempt to connect and login to IMAP. Returns (imap_conn, error_message)."""
    try:
        imap = imaplib.IMAP4_SSL(server) if use_ssl else imaplib.IMAP4(server)
        imap.login(email_address, password)
        imap.select(mailbox)
        return imap, None
    except imaplib.IMAP4.error as e:
        return None, f"IMAP error: {e}"
    except Exception as e:
        return None, f"Connection error: {e}"


# ----------------------------- Fetch Emails -----------------------------
# Fetches emails from an IMAP server or dummy data within a date range.
def fetch_emails(start_date: datetime, end_date: datetime, imap_conn=None):
    """
    Fetch emails between start_date and end_date (inclusive).
    If imap_conn is None or fails, fall back to dummy dataset.
    Returns list of dicts: {name, email, subject, snippet, date}.
    """
    print(f"Starting email fetch from {start_date} to {end_date}")
    
    # Normalize bounds (inclusive end)
    start_dt = datetime(start_date.year, start_date.month, start_date.day)
    end_dt = datetime(end_date.year, end_date.month, end_date.day, 23, 59, 59)
    
    print(f"Normalized date range: {start_dt} to {end_dt}")

    results = []

    if imap_conn is not None:
        try:
            # IMAP date search: SINCE start AND BEFORE end+1
            end_plus_one = end_dt + timedelta(days=1)
            criteria = f'(SINCE {to_imap_date(start_dt)} BEFORE {to_imap_date(end_plus_one)})'
            status, data = imap_conn.search(None, criteria)
            if status != 'OK':
                raise RuntimeError("IMAP search failed")
            ids = (data[0] or b"").split()
            if not ids:
                return results

            # Fetch all found emails in a single command to reduce network round-trips.
            # This is significantly faster than fetching each email in a loop.
            id_string = b','.join(ids)
            status, msg_data = imap_conn.fetch(id_string, '(RFC822)')
            
            if status != 'OK':
                raise RuntimeError("IMAP fetch failed")

            # The response for a bulk fetch is a flat list. We iterate through it,
            # processing only the tuples that contain the actual email data.
            for response_part in msg_data:
                if not isinstance(response_part, tuple):
                    continue

                raw = response_part[1]
                msg = email.message_from_bytes(raw)

                from_raw = msg.get('From', '')
                name, addr = parseaddr(from_raw)
                subj = safe_decode_header(msg.get('Subject', ''))
                body = parse_email_body(msg)

                snippet = (body or '').replace('\r', ' ').replace('\n', ' ')
                snippet = " ".join(snippet.split())[:200]

                # Date: try parsing from header; if fail, skip date filter (already filtered by server)
                date_hdr = msg.get('Date')
                msg_date = None
                try:
                    msg_date = parsedate_to_datetime(date_hdr) if date_hdr else None
                except Exception:
                    msg_date = None

                results.append({
                    "name": name or addr or "",
                    "email": addr or "",
                    "subject": subj,
                    "snippet": snippet,
                    "date": msg_date or datetime.now(),
                })
            return results
        except Exception as e:
            print(f"IMAP fetch error: {e}. Falling back to dummy data.")
            # Fall through to dummy
            pass

    # Dummy fallback
    for item in DUMMY_EMAILS:
        if start_dt <= item["date"] <= end_dt:
            snippet = " ".join((item["body"] or "").split())[:200]
            results.append({
                "name": item["name"],
                "email": item["email"],
                "subject": item["subject"],
                "snippet": snippet,
                "date": item["date"],
            })
    print(f"Found {len(results)} emails between {start_dt} and {end_dt}")
    return results


# ----------------------------- Theme Definitions -----------------------------
# Manages light and dark theme color schemes.
class ThemeManager:
    LIGHT_THEME = {
        'bg': '#DAA520',
        'primary': '#000000',
        'secondary': '#333333',
        'surface': '#ffffff',
        'text': '#000000',
        'text_secondary': '#444444',
        'border': '#c8c6c4',
        'accent': '#107c10',
        'warning': '#ffb900',
        'error': '#d83b01',
        'row_alt': '#f8f9fa'
    }
    
    DARK_THEME = {
        'bg': '#252525',
        'primary': '#2899f5',
        'secondary': '#5ca9e5',
        'surface': '#323232',
        'text': '#f5f5f5',
        'text_secondary': '#a0a0a0',
        'border': '#4a4a4a',
        'accent': '#28a745',
        'warning': '#ffc107',
        'error': '#dc3545',
        'row_alt': '#2c2c2c'
    }
    
    @classmethod
    # Returns the color dictionary for the selected theme.
    def get_theme(cls, is_dark: bool) -> dict:
        return cls.DARK_THEME if is_dark else cls.LIGHT_THEME

# ----------------------------- Dashboard UI -----------------------------
# Represents the dashboard window for displaying email analytics.
class DashboardWindow(tk.Toplevel):
    # Creates a hover-over tooltip for a given widget.
    def create_tooltip(self, widget, text):
        """Create a tooltip for a widget"""
        def show_tooltip(event=None):
            # Create tooltip window
            tooltip = tk.Toplevel()
            tooltip.withdraw()  # Hide initially
            tooltip.overrideredirect(True)  # Remove window decorations
            
            # Create tooltip content
            label = ttk.Label(tooltip, text=text, justify=tk.LEFT,
                            background="#ffffe0", relief=tk.SOLID,
                            borderwidth=1, padding=(5, 3))
            label.pack()
            
            def position_tooltip():
                # Get widget position
                x = widget.winfo_rootx() + widget.winfo_width()
                y = widget.winfo_rooty()
                
                # Adjust if tooltip would go off screen
                screen_width = widget.winfo_screenwidth()
                if x + tooltip.winfo_width() > screen_width:
                    x = screen_width - tooltip.winfo_width()
                
                tooltip.geometry(f"+{x}+{y}")
                tooltip.deiconify()  # Show tooltip
                
            tooltip.update_idletasks()  # Update tooltip size
            position_tooltip()
            
            def hide_tooltip():
                tooltip.destroy()
            
            # Store tooltip reference
            widget.tooltip = tooltip
            
            # Bind hide events
            widget.bind('<Leave>', lambda e: hide_tooltip())
            tooltip.bind('<Leave>', lambda e: hide_tooltip())
            widget.bind('<Button>', lambda e: hide_tooltip())
        
        # Bind show event
        widget.bind('<Enter>', lambda e: show_tooltip())
    
    # Displays a modal window with the full content of a selected email.
    def show_email_preview(self, event):
        """Show a preview window for the selected email"""
        try:
            selection = self.tree.selection()
            if not selection:
                return
                
            item = selection[0]
            values = self.tree.item(item)['values']
            if not values:
                return
            
            # Create preview window
            preview = tk.Toplevel(self)
            preview.title("Email Preview")
            preview.geometry("600x400")
            preview.grab_set()  # Make window modal
            
            # Configure preview window
            preview.configure(bg=self.colors['surface'])
            frame = ttk.Frame(preview, style='Content.TFrame', padding=15)
            frame.pack(fill=tk.BOTH, expand=True)
            
            # Email details
            ttk.Label(frame, text="From:", font=('Segoe UI', 11, 'bold'), style='Controls.TLabel').pack(anchor='w')
            ttk.Label(frame, text=f"{values[0]} <{values[1]}>", style='Controls.TLabel').pack(anchor='w', pady=(0,10))
            
            ttk.Label(frame, text="Subject:", font=('Segoe UI', 11, 'bold'), style='Controls.TLabel').pack(anchor='w')
            ttk.Label(frame, text=values[3], wraplength=550, style='Controls.TLabel').pack(anchor='w', pady=(0,10))
            
            ttk.Label(frame, text="Content:", font=('Segoe UI', 11, 'bold'), style='Controls.TLabel').pack(anchor='w')
            
            # Content text with scrollbar
            content_frame = ttk.Frame(frame, style='Controls.TFrame')
            content_frame.pack(fill=tk.BOTH, expand=True)
            
            scrollbar = ttk.Scrollbar(content_frame)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            content = tk.Text(content_frame, wrap=tk.WORD, height=10,
                            font=('Segoe UI', 11), padx=5, pady=5,
                            bg=self.colors['surface'], fg=self.colors['text'],
                            relief=tk.FLAT, borderwidth=0,
                            insertbackground=self.colors['text'])
            content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            
            content.insert('1.0', values[4])
            content.configure(state='disabled')  # Make read-only
            
            scrollbar.config(command=content.yview)
            content.config(yscrollcommand=scrollbar.set)
            
            # Close button
            ttk.Button(frame, text="Close", command=preview.destroy, style='Primary.TButton').pack(pady=(15,0))
            
            # Center window
            preview.update_idletasks()
            width = preview.winfo_width()
            height = preview.winfo_height()
            x = (preview.winfo_screenwidth() // 2) - (width // 2)
            y = (preview.winfo_screenheight() // 2) - (height // 2)
            preview.geometry(f'{width}x{height}+{x}+{y}')
            
        except Exception as e:
            print(f"Error showing email preview: {e}")
            messagebox.showerror("Error", "Could not display email preview")

    # Configures the ttk styles for the dashboard widgets.
    def setup_styles(self):
        try:
            style = ttk.Style()
            
            # Frame styles
            style.configure('Dashboard.TFrame', background=self.colors['bg'])
            style.configure('Controls.TFrame', background=self.colors['surface'])
            style.configure('Content.TFrame', background=self.colors['surface'])
            
            # Enhanced Treeview styling
            style.configure('Modern.Treeview',
                          background=self.colors['surface'],
                          foreground=self.colors['text'],
                          rowheight=self.tree_font_size * 3 + 10,
                          font=('Segoe UI', self.tree_font_size),
                          fieldbackground=self.colors['surface'])
            
            # Configure selection colors and alternating row colors
            style.map('Modern.Treeview',
                     background=[('selected', self.colors['primary'])],
                     foreground=[('selected', 'white')])
            
            # Configure tag colors for zebra striping
            self.tree.tag_configure('odd', background=self.colors['row_alt'])
            self.tree.tag_configure('even', background=self.colors['surface'])
            
            # Treeview heading style
            style.configure('Modern.Treeview.Heading', background=self.colors['bg'],
                       foreground=self.colors['text'], padding=(5, 5))
        
            # Scrollbar styles
            is_dark = self.is_dark_var.get()
            thumb_color = self.colors['text_secondary'] if is_dark else self.colors['text']
            
            style.configure('Modern.Vertical.TScrollbar', background=thumb_color,
                           troughcolor=self.colors['bg'], borderwidth=0, arrowsize=12)
            style.configure('Modern.Horizontal.TScrollbar', background=thumb_color,
                           troughcolor=self.colors['bg'], borderwidth=0, arrowsize=12)
        except Exception:
            pass

    # Initializes the dashboard window and its UI components.
    def __init__(self, master, is_dark_var, toggle_theme_callback, refresh_callback=None, user_email=""):
        super().__init__(master)
        self.title("Email Analytics Dashboard")
        self.state('zoomed')  # Start maximized
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.refresh_callback = refresh_callback
        self.is_dark_var = is_dark_var
        self.toggle_theme_callback = toggle_theme_callback
        self.user_email = user_email
        
        # Font size for treeview
        self.tree_font_size = 10
        
        # Modern color scheme
        self.colors = ThemeManager.get_theme(self.is_dark_var.get())
        
        self.configure(bg=self.colors['bg'])
        
        # Setup styles
        self.setup_styles()
        
        # Main container with padding
        container = ttk.Frame(self, style='Dashboard.TFrame')
        container.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Modern header with gradient effect
        self.header = tk.Frame(container, bg=self.colors['primary'], height=120)
        self.header.pack(fill=tk.X, pady=(0, 20))
        self.header.pack_propagate(False)
        
        # Left side: Title and summary
        self.header_left = tk.Frame(self.header, bg=self.colors['primary'])
        self.header_left.pack(side=tk.LEFT, fill=tk.Y)
        
        tk.Label(self.header_left,
                text="Email Analytics",
                font=('Segoe UI', 24, 'bold'),
                fg='white',
                bg=self.colors['primary']).pack(side=tk.TOP, padx=20, pady=(20,5))
                
        self.summary_var = tk.StringVar(value="0 emails")
        tk.Label(self.header_left,
                textvariable=self.summary_var,
                font=('Segoe UI', 12),
                fg='white',
                bg=self.colors['primary']).pack(side=tk.TOP, padx=20)
        
        # Right side: Statistics
        self.header_right = tk.Frame(self.header, bg=self.colors['primary'])
        self.header_right.pack(side=tk.RIGHT, fill=tk.Y, padx=20)
        
        # Theme toggle button
        self.theme_button = ttk.Checkbutton(
            self.header_right,
            text="☀️ Light Mode" if self.is_dark_var.get() else "🌙 Dark Mode",
            variable=self.is_dark_var,
            command=self.toggle_theme_callback,
            style="Switch.TCheckbutton"
        )
        self.theme_button.pack(side=tk.TOP, anchor='e', pady=(15, 5))

        self.stats_frame = tk.Frame(self.header_right, bg=self.colors['primary'])
        self.stats_frame.pack(side=tk.TOP, anchor='e', pady=10)
        
        # Statistics variables
        self.stats_vars = {
            'unique_senders': tk.StringVar(value="Unique Senders: 0"),
            'date_range': tk.StringVar(value="Date Range: -"),
            'avg_length': tk.StringVar(value="Avg. Length: -")
        }
        
        for var in self.stats_vars.values():
            tk.Label(self.stats_frame,
                    textvariable=var,
                    font=('Segoe UI', 10),
                    fg='white',
                    bg=self.colors['primary']).pack(anchor='e', pady=2)
                
        # Control bar with filter and export
        control_bar = ttk.Frame(container, style='Controls.TFrame')
        control_bar.pack(fill=tk.X, pady=(0, 20))
        
        # --- Left side of control bar (filters) ---
        left_controls = ttk.Frame(control_bar, style='Controls.TFrame')
        left_controls.pack(side=tk.LEFT)

        # Mailbox filter
        mailbox_filter_frame = ttk.Frame(left_controls, style='Controls.TFrame')
        mailbox_filter_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        self.mailbox_filter_var = tk.StringVar(value="All")
        ttk.Label(mailbox_filter_frame, text="Show:", style='Controls.TLabel').pack(side=tk.LEFT, padx=(0, 5))
        
        ttk.Radiobutton(mailbox_filter_frame, text="All", variable=self.mailbox_filter_var, value="All", command=self._apply_all_filters).pack(side=tk.LEFT)
        ttk.Radiobutton(mailbox_filter_frame, text="Received", variable=self.mailbox_filter_var, value="Received", command=self._apply_all_filters).pack(side=tk.LEFT)
        ttk.Radiobutton(mailbox_filter_frame, text="Sent", variable=self.mailbox_filter_var, value="Sent", command=self._apply_all_filters).pack(side=tk.LEFT)
        
        # Search bar on the left
        search_frame = ttk.Frame(left_controls, style='Controls.TFrame')
        search_frame.pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(search_frame, text="🔍 Search:", style='Controls.TLabel').pack(side=tk.LEFT)
        
        self.filter_var = tk.StringVar()
        self.filter_var.trace_add("write", self._apply_all_filters)
        
        filter_entry = ttk.Entry(search_frame, textvariable=self.filter_var, width=40)
        filter_entry.pack(side=tk.LEFT, padx=5)
        ToolTip(filter_entry, "Type to search across all fields")

        # Action buttons
        button_frame = ttk.Frame(control_bar, style='Controls.TFrame')
        button_frame.pack(side=tk.RIGHT)
        
        export_btn = ttk.Button(button_frame,
                              text="Export to CSV",
                              style='Accent.TButton',
                              command=self.export_csv)
        export_btn.pack(side=tk.RIGHT, padx=5)
        
        reset_btn = ttk.Button(button_frame,
                               text="Reset",
                               style='Primary.TButton',
                               command=self._reset_view)
        reset_btn.pack(side=tk.RIGHT, padx=5)
        ToolTip(reset_btn, "Reset search, sort, and zoom")
        
        # Sort menu button
        sort_menubutton = ttk.Menubutton(button_frame, text="Sort By", style='Primary.TButton')
        sort_menubutton.pack(side=tk.RIGHT, padx=5)

        sort_menu = tk.Menu(sort_menubutton, tearoff=0)
        sort_menubutton["menu"] = sort_menu

        sort_menu.add_command(label="Date (Newest First)", command=lambda: self._sort_by_date(descending=True))
        sort_menu.add_command(label="Date (Oldest First)", command=lambda: self._sort_by_date(descending=False))
        sort_menu.add_separator()
        sort_menu.add_command(label="Sender (A-Z)", command=lambda: self._sort_by_name(ascending=True))
        sort_menu.add_command(label="Sender (Z-A)", command=lambda: self._sort_by_name(ascending=False))
        
        ToolTip(sort_menubutton, "Change email sort order")
        
        # Zoom buttons
        zoom_in_btn = ttk.Button(button_frame, text="+", command=self._zoom_in, style='Primary.TButton', width=3)
        zoom_in_btn.pack(side=tk.RIGHT, padx=(5, 0))
        
        zoom_out_btn = ttk.Button(button_frame, text="-", command=self._zoom_out, style='Primary.TButton', width=3)
        zoom_out_btn.pack(side=tk.RIGHT, padx=(0, 5))
        
        # Create main content area with proper configuration
        content_frame = ttk.Frame(container, style='Content.TFrame')
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create tree frame for better layout management
        tree_frame = ttk.Frame(content_frame, style='Content.TFrame')
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        # Modern scrollbars
        vsb = ttk.Scrollbar(tree_frame,
                           orient="vertical",
                           style='Modern.Vertical.TScrollbar')
        hsb = ttk.Scrollbar(tree_frame,
                           orient="horizontal",
                           style='Modern.Horizontal.TScrollbar')
        
        # Treeview for emails with modern styling
        columns = ("Name", "Email Address", "Date", "Subject", "Body")
        self.tree = ttk.Treeview(tree_frame, 
                                columns=columns,
                                show='headings',
                                style='Modern.Treeview',
                                selectmode='browse',
                                height=20,  # Set default height
                                yscrollcommand=vsb.set,
                                xscrollcommand=hsb.set)
        
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)
        
        # Configure columns with modern proportions and better headers
        column_configs = [
            ("Name", 180, "Sender Name"),
            ("Email Address", 220, "Email Address"),
            ("Date", 150, "Date Received"),
            ("Subject", 250, "Email Subject"),
            ("Body", 400, "Content Preview"),
        ]
        
        # Configure each column properly
        for col, width, heading in column_configs:
            self.tree.heading(col, text=heading)
            self.tree.column(col, width=width, minwidth=80, anchor=tk.W, stretch=True)
            
        # Configure tag styles for better visibility
        self.tree.tag_configure('odd', background='#f8f9fa')
        self.tree.tag_configure('even', background=self.colors['surface'])
        
        # Add event handlers
        self.tree.bind('<Double-1>', self.show_email_preview)
        
        # Pack the treeview and scrollbars
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Setup modern styles
        self.setup_styles()

        self._all_rows = []
        self._start_str = ""
        self._end_str = ""

    # Applies the new theme (light/dark) to the dashboard.
    def update_theme(self, is_dark: bool):
        """Update the dashboard's theme."""
        self.colors = ThemeManager.get_theme(is_dark)
        self.configure(bg=self.colors['bg'])
        
        # Update theme button text
        self.theme_button.config(text="☀️ Light Mode" if is_dark else "🌙 Dark Mode")
        
        # Re-apply styles
        self.setup_styles()
        
        # Manually update non-ttk widgets
        for frame in [self.header, self.header_left, self.header_right, self.stats_frame]:
            frame.configure(bg=self.colors['primary'])
            for child in frame.winfo_children():
                if isinstance(child, tk.Label):
                    child.configure(bg=self.colors['primary'])
                
        # Rebuild tree to apply new row colors
        self._rebuild_tree(self._all_rows)

    # Hides the dashboard window instead of destroying it.
    def on_close(self):
        self.withdraw()

    # Refreshes the dashboard with new email data.
    def refresh(self, rows, start_str: str, end_str: str, user_email: Optional[str] = None):
        """Refresh the dashboard with new data"""
        try:
            print(f"Refreshing dashboard with {len(rows)} emails")
            
            # Store the data
            self._all_rows = rows if rows is not None else []
            self._start_str = start_str if start_str else ""
            self._end_str = end_str if end_str else ""
            if user_email is not None:
                self.user_email = user_email

            # Apply current filter to the new data, which will also rebuild the tree
            self._apply_all_filters()
            
            # Ensure visibility
            self.deiconify()
            self.lift()
            self.focus_force()
            
            # Make sure all columns are visible
            self.update_idletasks()
            for col in self.tree["columns"]:
                self.tree.column(col, stretch=True)
            
            print(f"Successfully displayed {len(self._all_rows)} emails")
            
        except Exception as e:
            print(f"Error refreshing dashboard: {e}")
            messagebox.showerror("Display Error", f"Failed to display fetched emails: {str(e)}")

    # Clears and repopulates the email list (treeview) with new data.
    def _rebuild_tree(self, rows):
        # Clear existing items
        try:
            for item in self.tree.get_children():
                self.tree.delete(item)
            
            # Calculate statistics
            count = len(rows)
            unique_senders = len({r.get("email", "").lower() for r in rows})
            
            # Calculate average content length
            total_length = sum(len(r.get("snippet", "")) for r in rows)
            avg_length = round(total_length / count) if count > 0 else 0
            
            # Update statistics
            self.summary_var.set(f"{count} {'email' if count == 1 else 'emails'}")
            if hasattr(self, 'stats_vars'):
                self.stats_vars['unique_senders'].set(f"Unique Senders: {unique_senders}")
                self.stats_vars['date_range'].set(f"Date Range: {self._start_str} to {self._end_str}")
                self.stats_vars['avg_length'].set(f"Avg. Content Length: {avg_length} chars")
            
            print(f"Displaying {count} emails in treeview")
            
            # Populate treeview with zebra striping
            for i, r in enumerate(rows):
                tags = ('even',) if i % 2 == 0 else ('odd',)
                date_obj = r.get("date")
                date_str = date_obj.strftime("%Y-%m-%d %H:%M") if date_obj else "N/A"
                values = (
                    r.get("name", ""),
                    r.get("email", ""),
                    date_str,
                    r.get("subject", ""),
                    r.get("snippet", ""),
                )
                self.tree.insert("", tk.END, values=values, tags=tags)
                
            # Ensure all items are visible
            if count > 0:
                self.tree.see(self.tree.get_children()[0])
                self.tree.update_idletasks()
                
        except Exception as e:
            print(f"Error rebuilding tree: {e}")
            messagebox.showerror("Display Error", "Error displaying emails in dashboard")

    # Resets all filters, sorting, and zoom to their default state.
    def _reset_view(self):
        """Reset search, sort, and zoom to their default states."""
        # Reset filters. Setting the search var will trigger the update, rebuilding the tree.
        self.mailbox_filter_var.set("All")
        self.filter_var.set("") 

        # Reset sort to default (Newest First)
        self._sort_by_date(descending=True)

        # Reset zoom
        self.tree_font_size = 10
        self._update_tree_font()

    # Applies the current search and mailbox filters to the email list.
    def _apply_all_filters(self, *args):
        """Filter the treeview based on mailbox and search entry."""
        # 1. Get current filter values
        mailbox_filter = self.mailbox_filter_var.get()
        search_text = self.filter_var.get().lower()

        # 2. Apply mailbox filter
        rows_to_filter = self._all_rows
        if self.user_email and mailbox_filter != "All":
            user_email_lower = self.user_email.lower()
            if mailbox_filter == "Received":
                rows_to_filter = [r for r in self._all_rows if r.get("email", "").lower() != user_email_lower]
            elif mailbox_filter == "Sent":
                # This is an approximation. It assumes the user's own email appears as the sender for sent items.
                rows_to_filter = [r for r in self._all_rows if r.get("email", "").lower() == user_email_lower]
        
        # 3. Apply search filter
        if not search_text:
            filtered_rows = rows_to_filter
        else:
            filtered_rows = []
            for row in rows_to_filter:
                # Check if filter text is in any of the relevant fields
                if (search_text in str(row.get("name", "")).lower() or
                    search_text in str(row.get("email", "")).lower() or
                    search_text in str(row.get("subject", "")).lower() or
                    search_text in str(row.get("snippet", "")).lower()):
                    filtered_rows.append(row)
        
        # 4. Rebuild tree
        self._rebuild_tree(filtered_rows)

    # Sorts the email list by date.
    def _sort_by_date(self, descending: bool):
        """Sort emails by date."""
        self._sort_tree_column("Date", reverse=descending)

    # Sorts the email list by sender name.
    def _sort_by_name(self, ascending: bool):
        """Sort emails by sender name."""
        self._sort_tree_column("Name", reverse=not ascending)

    # A generic helper function to sort the treeview by any column.
    def _sort_tree_column(self, column, reverse):
        """Sort tree contents by a specific column."""
        items = [(self.tree.set(k, column), k) for k in self.tree.get_children('')]

        # Sort (case-insensitive for strings)
        items.sort(key=lambda t: t[0].lower(), reverse=reverse)

        # Rearrange items in the tree
        for index, (val, k) in enumerate(items):
            self.tree.move(k, '', index)
        
        # After sorting, re-apply the zebra striping
        children = self.tree.get_children('')
        for i, child in enumerate(children):
            tag = 'even' if i % 2 == 0 else 'odd'
            self.tree.item(child, tags=(tag,))

    # Exports the current email data to a CSV file.
    def export_csv(self):
        try:
            from tkinter import filedialog
            path = filedialog.asksaveasfilename(parent=self, defaultextension=".csv", filetypes=[["CSV", "*.csv"]], title="Save results as CSV")
            if not path:
                return
            rows = self._all_rows
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Name", "Email Address", "Date", "Subject", "Body"]) 
                for r in rows:
                    date_obj = r.get("date")
                    date_str = date_obj.strftime("%Y-%m-%d %H:%M:%S") if date_obj else ""
                    writer.writerow([
                        r.get("name", ""), r.get("email", ""), date_str, r.get("subject", ""), r.get("snippet", "")
                    ])
            messagebox.showinfo("Exported", f"Saved {len(rows)} rows to {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Export Failed", f"Could not export CSV: {e}")

    # Updates the font size and row height of the email list.
    def _update_tree_font(self):
        """Update the treeview font size and row height."""
        try:
            style = ttk.Style()
            new_row_height = self.tree_font_size * 3 + 10
            style.configure('Modern.Treeview', 
                          font=('Segoe UI', self.tree_font_size), 
                          rowheight=new_row_height)
        except Exception as e:
            print(f"Error updating tree font: {e}")

    # Increases the font size in the email list.
    def _zoom_in(self):
        """Increase the font size of the treeview."""
        if self.tree_font_size < 20: # Max font size
            self.tree_font_size += 1
            self._update_tree_font()

    # Decreases the font size in the email list.
    def _zoom_out(self):
        """Decrease the font size of the treeview."""
        if self.tree_font_size > 6: # Min font size
            self.tree_font_size -= 1
            self._update_tree_font()


# ----------------------------- ToolTip Class -----------------------------
# A class to create simple hover tooltips for widgets.
class ToolTip:
    # Initializes the tooltip and binds mouse events.
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip = None
        self.widget.bind('<Enter>', self.enter)
        self.widget.bind('<Leave>', self.leave)

    # Creates and shows the tooltip window.
    def enter(self, event=None):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        
        self.tooltip = tk.Toplevel(self.widget)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry(f"+{x}+{y}")
        
        label = ttk.Label(self.tooltip, text=self.text, justify=tk.LEFT,
                         background="#ffffe0", relief=tk.SOLID, borderwidth=1,
                         padding=(5, 2))
        label.pack()

    # Destroys the tooltip window when the mouse leaves.
    def leave(self, event=None):
        if self.tooltip:
            self.tooltip.destroy()
            self.tooltip = None

# ----------------------------- Main Application -----------------------------
# The main application class for the email filter UI.
class EmailFilterApp:
    # Updates the text and color of the bottom status bar.
    def update_status(self, message, is_error=False):
        self.status_var.set(message)
        if is_error:
            self.status_bar.configure(foreground='red')
        else:
            self.status_bar.configure(foreground='black')
        self.root.update_idletasks()

    # Sets the date widgets for quick-select buttons (Today, 7 Days, etc.).
    def _set_date_range(self, days_ago: int):
        """Set start and end date widgets based on a day offset from today."""
        today = datetime.now().date()
        start_date = today - timedelta(days=days_ago)
        
        self._set_date(self.start_widget, start_date)
        self._set_date(self.end_widget, today)

    # Initializes the main application window and its UI components.
    def __init__(self, root):
        self.root = root
        self.root.title("Email Filter & Dashboard")
        # Make window resizable
        self.root.resizable(True, True)
        # Set window to full screen
        self.root.state('zoomed')

        self.is_bootstrap = BOOTSTRAP_AVAILABLE and isinstance(root, tb.Window)

        self.dashboard = None  # type: DashboardWindow | None
        self._last_rows = []
        
        # Initialize default date
        self.default_date = datetime.now().date()
        
        # Create main container with padding that expands
        main = ttk.Frame(root, padding=16)
        main.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Configure main frame grid to allow content to expand
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)  # Allow date frame to grow slightly
        main.grid_rowconfigure(2, weight=3)  # Allow IMAP frame to grow significantly
        
        # Add a title label at the top
        title_label = ttk.Label(main, text="📧 Email Filter & Dashboard", 
                               font=('Segoe UI', 22, 'bold'))
        title_label.grid(row=0, column=0, pady=(0, 20), sticky='n')
        
        # Theme toggle
        self.is_dark_mode = tk.BooleanVar(value=False)
        self.theme_button = ttk.Checkbutton(main, text="🌙 Dark Mode", variable=self.is_dark_mode, command=self.toggle_theme, style="Switch.TCheckbutton")
        self.theme_button.grid(row=0, column=0, sticky='ne', padx=20, pady=5)
        
        # Create ToolTip class for hover help
        self.tooltips = []

        # Create a frame for date selection with improved styling
        date_frame = ttk.LabelFrame(main, text="Date Range", padding=(15, 10))
        date_frame.grid(row=1, column=0, sticky='nsew', pady=(0, 15), padx=20)
        
        # Configure date_frame grid to allow expansion
        date_frame.grid_columnconfigure(1, weight=1)
        date_frame.grid_columnconfigure(3, weight=1)
        date_frame.grid_rowconfigure(0, weight=1) # Center content vertically
        
        # Start date
        ttk.Label(date_frame, text="Start Date:", style='Controls.TLabel').grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self.start_widget = self._create_date_widget(date_frame)
        self.start_widget.grid(row=0, column=1, sticky='ew', padx=(0, 20))

        # End date
        ttk.Label(date_frame, text="End Date:", style='Controls.TLabel').grid(row=0, column=2, sticky=tk.W, padx=(0, 5))
        self.end_widget = self._create_date_widget(date_frame)
        self.end_widget.grid(row=0, column=3, sticky='ew', padx=(0, 20))
        
        # Quick select buttons
        quick_select_frame = ttk.Frame(date_frame)
        quick_select_frame.grid(row=0, column=4, sticky='e', padx=(10, 0))
        
        ttk.Button(quick_select_frame, text="Today", command=lambda: self._set_date_range(0)).pack(side=tk.LEFT, padx=2)
        ttk.Button(quick_select_frame, text="7 Days", command=lambda: self._set_date_range(6)).pack(side=tk.LEFT, padx=2)
        ttk.Button(quick_select_frame, text="30 Days", command=lambda: self._set_date_range(29)).pack(side=tk.LEFT, padx=2)
        
        self.tooltips.append(ToolTip(self.start_widget, "Select starting date (YYYY-MM-DD)"))
        self.tooltips.append(ToolTip(self.end_widget, "Select ending date (YYYY-MM-DD)"))

        # Create a frame for IMAP settings with improved styling
        imap_frame = ttk.LabelFrame(main, text="Email Settings", padding=(15, 10))
        imap_frame.grid(row=2, column=0, sticky='nsew', pady=(0, 15), padx=20)
        
        # Configure imap_frame grid to expand
        imap_frame.grid_columnconfigure(0, weight=1)
        imap_frame.grid_columnconfigure(1, weight=1)
        imap_frame.grid_rowconfigure(1, weight=1)

        # IMAP Toggle with improved styling
        self.use_imap_var = tk.BooleanVar(value=False)
        imap_chk = ttk.Checkbutton(imap_frame, text="Connect to Email Account", 
                                  variable=self.use_imap_var, 
                                  command=self._toggle_imap_fields)
        imap_chk.grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 10))
        self.tooltips.append(ToolTip(imap_chk, "Enable to fetch emails from your account"))

        # IMAP Fields (disabled until checkbox is on)
        self.server_var = tk.StringVar(value="imap.gmail.com")
        self.email_var = tk.StringVar(value="")
        self.password_var = tk.StringVar(value="")
        self.mailbox_var = tk.StringVar(value="INBOX")

        # Create two frames for better organization of fields
        left_fields = ttk.Frame(imap_frame)
        right_fields = ttk.Frame(imap_frame)
        
        left_fields.grid(row=1, column=0, sticky='nsew', padx=(0,10))
        right_fields.grid(row=1, column=1, sticky='nsew', padx=(10,0))
        
        # Configure columns and rows to expand within the field frames
        for frame in (left_fields, right_fields):
            frame.grid_columnconfigure(1, weight=1)
            frame.grid_rowconfigure(0, weight=1)
            frame.grid_rowconfigure(1, weight=1)

        # Email field (left side)
        ttk.Label(left_fields, text="Email:").grid(row=0, column=0, sticky=tk.W, pady=5, padx=5)
        self.email_entry = ttk.Entry(left_fields, textvariable=self.email_var)
        self.email_entry.grid(row=0, column=1, sticky='ew', padx=5, pady=5)
        self.tooltips.append(ToolTip(self.email_entry, "Your email address"))
        
        # Server field (left side)
        ttk.Label(left_fields, text="Server:").grid(row=1, column=0, sticky=tk.W, pady=5, padx=5)
        self.server_entry = ttk.Entry(left_fields, textvariable=self.server_var)
        self.server_entry.grid(row=1, column=1, sticky='ew', padx=5, pady=5)
        self.tooltips.append(ToolTip(self.server_entry, "Gmail: imap.gmail.com\nOutlook: outlook.office365.com"))

        # Password field (right side)
        ttk.Label(right_fields, text="Password:").grid(row=0, column=0, sticky=tk.W, pady=5, padx=5)
        self.password_entry = ttk.Entry(right_fields, textvariable=self.password_var, show="●")
        self.password_entry.grid(row=0, column=1, sticky='ew', padx=5, pady=5)
        self.tooltips.append(ToolTip(self.password_entry, "Your email password or app-specific password"))
        
        # Mailbox field (right side)
        ttk.Label(right_fields, text="Folder:").grid(row=1, column=0, sticky=tk.W, pady=5, padx=5)
        self.mailbox_entry = ttk.Entry(right_fields, textvariable=self.mailbox_var)
        self.mailbox_entry.grid(row=1, column=1, sticky='ew', padx=5, pady=5)
        self.tooltips.append(ToolTip(self.mailbox_entry, "Email folder to search (default: INBOX)"))

        # Create a frame for progress and buttons
        control_frame = ttk.Frame(main)
        control_frame.grid(row=3, column=0, sticky='nsew', pady=(0, 15), padx=20)
        control_frame.grid_columnconfigure(0, weight=1)

        # Progress bar
        prog_frame = ttk.Frame(control_frame)
        prog_frame.grid(row=0, column=0, sticky='ew', pady=(0, 15))
        prog_frame.grid_columnconfigure(0, weight=1)
        
        self.progress = ttk.Progressbar(prog_frame, mode="indeterminate")
        self.progress.grid(row=0, column=0, sticky='ew')

        # Button frame with center alignment
        button_frame = ttk.Frame(control_frame)
        button_frame.grid(row=1, column=0, sticky='ew')
        
        # Configure button frame for center alignment
        for i in range(6):
            button_frame.grid_columnconfigure(i, weight=1)

        button_style = "primary.TButton" if self.is_bootstrap else "Primary.TButton"

        # Main buttons with consistent width and proper spacing
        self.fetch_btn = ttk.Button(button_frame, text="📧 Fetch Emails", command=self.on_fetch, width=15, style=button_style)
        self.fetch_btn.grid(row=0, column=1, padx=5)
        
        dashboard_btn = ttk.Button(button_frame, text="Dashboard", command=self.show_dashboard, width=15, style=button_style)
        dashboard_btn.grid(row=0, column=2, padx=5)
        
        help_btn = ttk.Button(button_frame, text="Help", command=self.show_help, width=15, style=button_style)
        help_btn.grid(row=0, column=3, padx=5)

        quit_btn = ttk.Button(button_frame, text="Quit", command=self.root.destroy, width=15, style=button_style)
        quit_btn.grid(row=0, column=4, padx=5)

        # Status bar at the bottom
        self.status_var = tk.StringVar(value="Ready")
        self.status_bar = ttk.Label(root, textvariable=self.status_var, relief=tk.SUNKEN, padding=(10, 5))
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Set default dates
        self._set_date(self.start_widget, self.default_date)
        self._set_date(self.end_widget, self.default_date)
        
        # Initialize IMAP fields state
        self._toggle_imap_fields()

        # Initialize styles and apply theme
        self.setup_styles()
        self.apply_theme()

        # Load settings
        try:
            self._load_settings()
        except Exception:
            pass

        # Shortcuts
        root.bind("<Return>", lambda e: self.on_fetch())
        root.bind("<Control-d>", lambda e: self.show_dashboard())
        root.bind("<Escape>", lambda e: self.root.destroy())

    # Creates a date entry widget (using a calendar if available).
    def _create_date_widget(self, parent):
        current_date = datetime.now().date()
        
        # Use tkcalendar DateEntry if available for a calendar picker
        if TKCAL_AVAILABLE and TKCalDateEntry is not None:
            try:
                # The DateEntry widget includes its own dropdown button for the calendar.
                widget = TKCalDateEntry(parent, date_pattern="yyyy-mm-dd", width=16, style='TEntry')
                widget.set_date(current_date)
                return widget
            except Exception as e:
                print(f"Could not create TKCalDateEntry, falling back to simple Entry: {e}")

        # Fallback: simple Entry with YYYY-MM-DD
        # This will be used if tkcalendar is not installed.
        entry = ttk.Entry(parent, width=18)
        entry.insert(0, current_date.strftime("%Y-%m-%d"))
        return entry

    # Reads and parses the date from a date widget.
    def _get_date(self, widget) -> Optional[datetime]:
        # Handle tkcalendar DateEntry
        if TKCAL_AVAILABLE and TKCalDateEntry is not None and isinstance(widget, TKCalDateEntry):
            try:
                d = widget.get_date()
                return datetime(d.year, d.month, d.day)
            except Exception:
                # Fallback to reading text if get_date fails
                pass
        
        # Handle fallback ttk.Entry or text from DateEntry
        s = widget.get().strip()
        try:
            return datetime.strptime(s, "%Y-%m-%d")
        except (ValueError, TypeError):
            return None

    # Sets the date value of a date widget.
    def _set_date(self, widget, d):
        # Handle tkcalendar DateEntry
        if TKCAL_AVAILABLE and TKCalDateEntry is not None and isinstance(widget, TKCalDateEntry):
            try:
                widget.set_date(d)
                return
            except Exception:
                # Fallback to setting text if set_date fails
                pass
        
        # Handle fallback ttk.Entry or text for DateEntry
        widget.delete(0, tk.END)
        widget.insert(0, d.strftime("%Y-%m-%d"))

    # Initializes the ttk styles for the application.
    def setup_styles(self):
        self.style = ttk.Style()
        # This will be populated by apply_theme
        pass

    # Applies the current theme (light/dark) to all UI components.
    def apply_theme(self):
        is_dark = self.is_dark_mode.get()
        self.theme_button.config(text="☀️ Light Mode" if is_dark else "🌙 Dark Mode")
        
        theme = ThemeManager.get_theme(is_dark)
        
        button_style = "Primary.TButton"
        if self.is_bootstrap:
            theme_name = "darkly" if is_dark else "cosmo"
            self.root.style.theme_use(theme_name)
            button_style = "primary.TButton"
        else:
            # Update root and styles
            self.root.configure(bg=theme['bg'])
            self.style.theme_use('default') # Reset to base theme

        # General widget styling
        self.style.configure('.', background=theme['bg'], foreground=theme['text'], font=('Segoe UI', 11))
        self.style.configure('TFrame', background=theme['bg'])
        self.style.configure('TLabel', background=theme['bg'], foreground=theme['text'])
        self.style.configure('TCheckbutton', background=theme['bg'], foreground=theme['text'])
        self.style.map('TCheckbutton',
                       background=[('active', theme['bg'])],
                       indicatorcolor=[('selected', theme['primary']), ('!selected', theme['surface'])],
                       foreground=[('active', theme['text'])])

        # Special styles
        self.style.configure('Switch.TCheckbutton', font=('Segoe UI', 11)) # For the theme button
        self.style.configure('Controls.TLabel', background=theme['surface'], foreground=theme['text'])
        self.style.configure('TLabelFrame', background=theme['bg'], bordercolor=theme['border'])
        self.style.configure('TLabelFrame.Label', background=theme['bg'], foreground=theme['text_secondary'])
        self.style.configure('TEntry', fieldbackground=theme['surface'], foreground=theme['text'],
                           bordercolor=theme['border'], insertcolor=theme['text'])
        self.style.map('TEntry', bordercolor=[('focus', theme['primary'])])
        
        # Button styling
        self.style.configure(button_style, padding=6, font=('Segoe UI', 11, 'bold'),
                           background=theme['primary'], foreground='white')
        self.style.map(button_style,
                       background=[('active', theme['secondary']), ('disabled', theme['border'])])

        # Progress bar
        self.style.configure('TProgressbar', background=theme['accent'], troughcolor=theme['surface'])
        
        # Status bar
        self.status_bar.configure(background=theme['surface'], foreground=theme['text_secondary'])

        # If dashboard exists, update its theme
        if self.dashboard and self.dashboard.winfo_exists():
            self.dashboard.update_theme(is_dark)

    # Toggles the color theme between light and dark mode.
    def toggle_theme(self):
        self.apply_theme()

    # Creates the dashboard window if it doesn't exist.
    def _ensure_dashboard(self):
        if self.dashboard is None or not self.dashboard.winfo_exists():
            self.dashboard = DashboardWindow(
                self.root, 
                is_dark_var=self.is_dark_mode, 
                toggle_theme_callback=self.toggle_theme, 
                refresh_callback=self.on_fetch,
                user_email=self.email_var.get()
            )
            self.dashboard.withdraw()
        return self.dashboard

    # Handles the 'Fetch Emails' button click event.
    def on_fetch(self):
        # Run fetching in background to keep UI responsive
        start_dt = self._get_date(self.start_widget)
        end_dt = self._get_date(self.end_widget)
        if not start_dt or not end_dt:
            messagebox.showerror("Invalid Dates", "Please enter valid dates in YYYY-MM-DD format.")
            return
        if end_dt < start_dt:
            messagebox.showerror("Invalid Range", "End Date must be on or after Start Date.")
            return

        self._start_progress()
        self.status_var.set("Fetching emails...")

        def work():
            imap_conn_local = None
            if self.use_imap_var.get():
                imap_conn_local = self._connect_imap_from_fields()
                if self.use_imap_var.get() and imap_conn_local is None:
                    self.root.after(0, lambda: messagebox.showerror("IMAP Login Failed", "Falling back to dummy data. Check server and credentials."))
            try:
                rows_local = fetch_emails(start_dt, end_dt, imap_conn_local)
            except Exception as e:
                rows_local = None
                self.root.after(0, lambda: messagebox.showerror("Fetch Error", f"An error occurred while fetching emails: {e}"))
            finally:
                try:
                    if imap_conn_local is not None:
                        imap_conn_local.logout()
                except Exception:
                    pass

            def finish():
                try:
                    self._stop_progress()
                    
                    # Create or get dashboard
                    if self.dashboard is None or not self.dashboard.winfo_exists():
                        self.dashboard = DashboardWindow(self.root, is_dark_var=self.is_dark_mode, toggle_theme_callback=self.toggle_theme, refresh_callback=self.on_fetch)
                    
                    # Process results
                    if not rows_local:
                        print("No emails found")
                        messagebox.showinfo("No Emails", "No emails found for the selected date range.")
                        self.dashboard.refresh([], start_dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))
                        self.status_var.set("No emails found")
                        return
                    
                    # Store the results
                    print(f"Processing {len(rows_local)} emails")
                    self._last_rows = rows_local
                    
                    # Format dates
                    start_str = start_dt.strftime("%Y-%m-%d")
                    end_str = end_dt.strftime("%Y-%m-%d")
                    
                    # Update dashboard
                    print("Updating dashboard")
                    self.dashboard.refresh(
                        rows_local, 
                        start_str, 
                        end_str,
                        user_email=self.email_var.get()
                    )
                    
                    # Ensure dashboard is visible
                    self.dashboard.deiconify()
                    self.dashboard.lift()
                    self.dashboard.focus_force()
                    
                    # Update main window status
                    self.status_var.set(f"Fetched {len(rows_local)} emails")
                    print(f"Successfully displayed {len(rows_local)} emails")
                    
                    # Save settings
                    try:
                        self._save_settings()
                    except Exception as e:
                        print(f"Error saving settings: {e}")
                        
                except Exception as e:
                    print(f"Error in fetch completion: {e}")
                    self._stop_progress()
                    messagebox.showerror("Error", f"Failed to display fetched emails: {str(e)}")
                    self.status_var.set("Error displaying emails")

            self.root.after(0, finish)

        import threading
        threading.Thread(target=work, daemon=True).start()

    # Makes the dashboard window visible.
    def show_dashboard(self):
        self._ensure_dashboard()
        self.dashboard.deiconify()

    # Displays a help window with instructions.
    def show_help(self):
        help_text = """Email Filter & Dashboard Help

Date Range:
- Start Date: Select the beginning date for email filtering
- End Date: Select the ending date for email filtering

Email Account Settings:
- Use IMAP: Enable to fetch from email account
- Server: Your email provider's IMAP server
  • Gmail: imap.gmail.com
  • Outlook: outlook.office365.com
- Email: Your email address
- Password: Your email password or app-specific password
- Mailbox: Email folder to search (default: INBOX)

Keyboard Shortcuts:
- Enter: Fetch emails
- Ctrl+D: Show dashboard
- Esc: Close window

Note: For Gmail, you need to:
1. Enable 2-Step Verification
2. Generate an App Password
3. Use the App Password instead of your regular password"""
        
        help_window = tk.Toplevel(self.root)
        help_window.title("Help")
        help_window.geometry("500x600")
        
        theme = ThemeManager.get_theme(self.is_dark_mode.get())
        help_window.configure(bg=theme['surface'])
        
        text = tk.Text(help_window, wrap=tk.WORD, padx=10, pady=10,
                       bg=theme['surface'], fg=theme['text'], relief=tk.FLAT, borderwidth=0)
        text.pack(fill=tk.BOTH, expand=True)
        text.insert("1.0", help_text)
        text.config(state=tk.DISABLED)
        
        close_btn = ttk.Button(help_window, text="Close", command=help_window.destroy)
        close_btn.pack(pady=10)

    # Starts the indeterminate progress bar animation.
    def _start_progress(self):
        try:
            self.progress.start(12)
        except Exception:
            pass
    # Stops the progress bar animation.
    def _stop_progress(self):
        try:
            self.progress.stop()
        except Exception:
            pass

    # ---------------- Settings persistence ----------------
    # Returns the file path for storing user settings.
    def _settings_path(self) -> str:
        try:
            base = os.path.dirname(os.path.abspath(__file__))
        except Exception:
            base = os.getcwd()
        return os.path.join(base, "email_filter_settings.json")

    # Saves current settings (IMAP credentials, dates) to a JSON file.
    def _save_settings(self):
        data = {
            "use_imap": bool(self.use_imap_var.get()),
            "server": self.server_var.get(),
            "email": self.email_var.get(),
            "mailbox": self.mailbox_var.get(),
            "start": self._get_date_string(self.start_widget),
            "end": self._get_date_string(self.end_widget),
        }
        with open(self._settings_path(), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    # Loads settings from the JSON file on startup.
    def _load_settings(self):
        path = self._settings_path()
        if not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        try:
            self.use_imap_var.set(bool(data.get("use_imap", False)))
            self.server_var.set(data.get("server", "imap.gmail.com"))
            self.email_var.set(data.get("email", ""))
            self.mailbox_var.set(data.get("mailbox", "INBOX"))
            if data.get("start"):
                self._set_date_text(self.start_widget, data.get("start"))
            if data.get("end"):
                self._set_date_text(self.end_widget, data.get("end"))
            self._toggle_imap_fields()
        except Exception:
            pass

    # Gets the date from a widget as a formatted string.
    def _get_date_string(self, widget) -> str:
        d = self._get_date(widget)
        return d.strftime("%Y-%m-%d") if d else ""

    # Sets the date on a widget from a formatted string.
    def _set_date_text(self, widget, text: str):
        try:
            d = datetime.strptime((text or "").strip(), "%Y-%m-%d")
            self._set_date(widget, d)
        except Exception:
            pass

    # Connects to the IMAP server using credentials from the UI.
    def _connect_imap_from_fields(self):
        server = (self.server_var.get() or "").strip()
        email_address = (self.email_var.get() or "").strip()
        password = self.password_var.get() or ""
        mailbox = (self.mailbox_var.get() or "INBOX").strip() or "INBOX"

        if not server or not email_address or not password:
            messagebox.showerror("Missing IMAP Info", "Please fill Server, Email, and Password.")
            return None

        imap, err = connect_imap(server, email_address, password, use_ssl=True, mailbox=mailbox)
        if err:
            return None
        return imap

    # Enables or disables the IMAP input fields based on the checkbox.
    def _toggle_imap_fields(self):
        state = tk.NORMAL if self.use_imap_var.get() else tk.DISABLED
        for widget in [self.server_entry, self.email_entry, self.password_entry, self.mailbox_entry]:
            widget.configure(state=state)

# The main entry point for the application.
def main():
    if BOOTSTRAP_AVAILABLE:
        # Use a ttkbootstrap theme that has rounded buttons by default
        root = tb.Window(themename="cosmo")
    else:
        root = tk.Tk()
    EmailFilterApp(root)
    root.mainloop()


# Ensures the main function runs only when the script is executed directly.
if __name__ == "__main__":
    main()


